<template>
  <div class="grid grid-cols-1 gap-5 sm:grid-cols-2">
    <div>
      <img
        src="/images/grid-image/image-02.png"
        alt="grid"
        class="w-full border border-gray-200 rounded-xl dark:border-gray-800"
      />
    </div>

    <div>
      <img
        src="/images/grid-image/image-03.png"
        alt="grid"
        class="w-full border border-gray-200 rounded-xl dark:border-gray-800"
      />
    </div>
  </div>
</template>
